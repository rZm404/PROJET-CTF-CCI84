// Ajoute moi dans ton dev tools de ton browser favoris,
// Lance reseed(38) dans la console puis avant timeout solve()
// Le flag s'affiche et l'onglet Network permet de le lire plus longtemps

function len(s) {
    let i=0;
    for (let prop in s) {
        if (s[prop] === true)
            i += 1;
    }
    return i;
}

function solve() {
    // Dijkstra!
    let candidates = {};
    candidates[JSON.stringify(maze.startCoord)] = true;
    let costs = {};
    costs[JSON.stringify(maze.startCoord)] = 0;
    let explored = {};
    let prevs = {};
    prevs[JSON.stringify(maze.startCoord)] = null;

    // mod direction to keystroke
    const dir2move = {
        n: 38,
        w: 37,
        s: 40,
        e: 39
    };

    while (len(candidates) > 0 && explored[JSON.stringify(maze.endCoord)] !== true) {
        // Select candidate with the lowest score
        let minCost = 1000;
        let minCand = null;
        for (let cand in candidates) {
            if (candidates[cand] !== true)
                continue;
            if (costs[cand] < minCost) {
                minCost = costs[cand];
                minCand = cand;
            }
        }
        // Mark it explored, remove it from candidates
        cand = minCand;
        explored[cand] = true;
        delete candidates[cand];

        // Browse its neighbours
        let cand_ = JSON.parse(cand);
        cell = maze.mazeMap[cand_.x][cand_.y];
        let next;
        if (cell.n) {
            next = {
                x: cand_.x + maze.modDir.n.x,
                y: cand_.y + maze.modDir.n.y
            }
            // If it's closer this way, record this new path
            next = JSON.stringify(next);
            if (explored[next] !== true && (candidates[next] !== true || costs[next] < costs[cand]+1)) {
                prevs[next] = [cand, dir2move.n];
                costs[next] = costs[cand]+1;
                candidates[next] = true;
            }
        }
        if (cell.w) {
            next = {
                x: cand_.x + maze.modDir.w.x,
                y: cand_.y + maze.modDir.w.y
            }
            next = JSON.stringify(next);
            if (explored[next] !== true && (candidates[next] !== true || costs[next] < costs[cand]+1)) {
                prevs[next] = [cand, dir2move.w];
                costs[next] = costs[cand]+1;
                candidates[next] = true;
            }
        }
        if (cell.s) {
            next = {
                x: cand_.x + maze.modDir.s.x,
                y: cand_.y + maze.modDir.s.y
            }
            next = JSON.stringify(next);
            if (explored[next] !== true && (candidates[next] !== true || costs[next] < costs[cand]+1)) {
                prevs[next] = [cand, dir2move.s];
                costs[next] = costs[cand]+1;
                candidates[next] = true;
            }
        }
        if (cell.e) {
            next = {
                x: cand_.x + maze.modDir.e.x,
                y: cand_.y + maze.modDir.e.y
            }
            next = JSON.stringify(next);
            if (explored[next] !== true && (candidates[next] !== true || costs[next] < costs[cand]+1)) {
                prevs[next] = [cand, dir2move.e];
                costs[next] = costs[cand]+1;
                candidates[next] = true;
            }
        }
    }

    // Find the path of events from the end and validate
    let prev = JSON.stringify(maze.endCoord);
    let  dir;
    while(prevs[prev] != null) {
        [prev, dir] = prevs[prev];
        player.moves.unshift({keyCode: dir});
    }

    // Validate the puzzle
    player.onComplete(player.moves);
}

function reseed(difficulty = 10) {
    fetch('get_seed', {method: 'POST'})
    .then((res) => res.json())
    .then((data) => {
        console.log("Seed bien récupérée");
        setTimeout(function(){
            makeMaze(data.seed, difficulty);
        }, 500);
    })
    .catch((err) => console.error(err))
}
