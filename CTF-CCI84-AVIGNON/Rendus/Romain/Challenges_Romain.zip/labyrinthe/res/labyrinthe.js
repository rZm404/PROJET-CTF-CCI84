// 2022 ang3l, Miaou

//Créer le setup du labyrinthe
function Maze(width, height, seed) {
    this.mazeMap = undefined;
    this.width = width;
    this.height = height;
    this.startCoord = undefined;
    this.endCoord = undefined;
    this.dirs = ["n", "s", "e", "w"];
    this.modDir = {
        n: {
        y: -1,
        x: 0,
        o: "s"
        },
        s: {
        y: 1,
        x: 0,
        o: "n"
        },
        e: {
        y: 0,
        x: 1,
        o: "w"
        },
        w: {
        y: 0,
        x: -1,
        o: "e"
        }
    };

    // Utilise le module seedrandom
    this.seed = seed;
    this.prng = new Math.seedrandom(seed);

    this.rand = function(max) {
        return Math.abs(this.prng.int32())%max;
    }

    this.shuffle = function(a) {
        for (let i = a.length - 1; i > 0; i--) {
            const j = this.rand(i+1);
            [a[i], a[j]] = [a[j], a[i]];
        }
        return a;
    }

    this.map = function() {
        return this.mazeMap;
    };

    // Génère le support du laby
    this.mazeMap = new Array(this.height);
    for (y = 0; y < height; y++) {
        this.mazeMap[y] = new Array(this.width);
        for (x = 0; x < this.width; ++x) {
            this.mazeMap[y][x] = {
                n: false,
                s: false,
                e: false,
                w: false,
                visited: false,
                priorPos: null
            };
        }
    }

// ##################### Réfléchir ici ################### //
    // Fonction de génération du laby
    // (doit être membre de this pour être bindée au même objet, même si du coup elle est publique)
    this.defineMaze = function() {
        var estComplet = false;
        var move = false;
        var cellsVisited = 1;
        var numLoops = 0;
        var maxLoops = 0;
        var pos = {
            x: 0,
            y: 0
        };
        var numCells = this.width * this.height;
        // TODO: quel algorithme a été utilisé ?
        while (!estComplet) {
            move = false;
            this.mazeMap[pos.x][pos.y].visited = true;

            // Si on ne shuffle qu'au bout de maxLoops, le laby aura une forme de symétrie (on cherche toujours le même chemin d'abord)
            if (numLoops >= maxLoops) {
                this.shuffle(this.dirs);
                maxLoops = this.rand(Math.round(height / 8));
                numLoops = 0;
            }
            numLoops++;
            for (index = 0; index < this.dirs.length; index++) {
                var direction = this.dirs[index];
                var nx = pos.x + this.modDir[direction].x;
                var ny = pos.y + this.modDir[direction].y;

                if (nx >= 0 && nx < this.width && ny >= 0 && ny < this.height) {
                    ////Vérifier si le chemin a déjà été visité
                    if (!this.mazeMap[nx][ny].visited) {
                        //Tailler à travers les murs de ce chemin au suivant
                        this.mazeMap[pos.x][pos.y][direction] = true;
                        this.mazeMap[nx][ny][this.modDir[direction].o] = true;

                        //Currentcell -> cellules visitées
                        this.mazeMap[nx][ny].priorPos = pos;
                        //Mettre à jour la position de la cellule au nouvel emplacement
                        pos = {
                            x: nx,
                            y: ny
                        };
                        cellsVisited++;
                        //Appelez récursivement cette méthode sur le chemin suivante
                        // FIXME: pas d'appel récursif ici
                        move = true;
                        break;
                    }
                }
            }

            if (!move) {
                // Si on ne trouve pas de direction on recule et on rappelle la méthode
                pos = this.mazeMap[pos.x][pos.y].priorPos;
            }
            //Si on a parcouru tout le lab on arrête
            if (numCells == cellsVisited) {
                estComplet = true;
            }
        }
    }

    //Définir début et fin
    switch (this.rand(4)) {
    case 0:
        this.startCoord = {
            x: 0,
            y: 0
        };
        this.endCoord = {
            x: height - 1,
            y: width - 1
        };
        break;
    case 1:
        this.startCoord = {
            x: 0,
            y: width - 1
        };
        this.endCoord = {
            x: height - 1,
            y: 0
        };
        break;
    case 2:
        this.startCoord = {
            x: height - 1,
            y: 0
        };
        this.endCoord = {
            x: 0,
            y: width - 1
        };
        break;
    case 3:
        this.startCoord = {
            x: height - 1,
            y: width - 1
        };
        this.endCoord = {
            x: 0,
            y: 0
        };
        break;
    }

    this.defineMaze();
}

//Session
function Player(maze, onComplete) {
    this.maze = maze;
    this.map = maze.map();
    this.cellCoords = {
        x: this.maze.startCoord.x,
        y: this.maze.startCoord.y
    };
    this.onComplete = onComplete;
    this.completed = false;
    this.moves = [];

    // Traite un event et fait bouger le joueur si c'est possible + redessine
    this.check = function(e) {
        var cell = this.map[this.cellCoords.x][this.cellCoords.y];//localiser la cellule
        const oldCoords = {...this.cellCoords};
        switch (e.keyCode) {
            case 81:
            case 37: // ouest
                if (cell.w == true) {
                    this.cellCoords = {
                        x: this.cellCoords.x - 1,
                        y: this.cellCoords.y
                    };
                }
                break;
            case 90:
            case 38: // nord
                if (cell.n == true) {
                    this.cellCoords = {
                        x: this.cellCoords.x,
                        y: this.cellCoords.y - 1
                    };
                }
                break;
            case 68:
            case 39: // est
                if (cell.e == true) {
                    this.cellCoords = {
                        x: this.cellCoords.x + 1,
                        y: this.cellCoords.y
                    };
                }
                break;
            case 83:
            case 40: // sud
                if (cell.s == true) {
                    this.cellCoords = {
                        x: this.cellCoords.x,
                        y: this.cellCoords.y + 1
                    };
                }
                break;
        }
        // Si mouvement
        if (oldCoords.x != this.cellCoords.x || oldCoords.y != this.cellCoords.y)
        {
            this.moves.push({keyCode: e.keyCode});
        }
        // Si réussite
        if (this.cellCoords.x === this.maze.endCoord.x && this.cellCoords.y === this.maze.endCoord.y) {
            this.completed = true;
            this.onComplete(this.moves);
        }
    }
}

if(module != undefined) {
    module.exports = {Maze, Player};
}
