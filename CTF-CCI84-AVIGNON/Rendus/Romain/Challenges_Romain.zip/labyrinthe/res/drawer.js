// 2022 ang3l, Miaou

function changeBrightness(factor, sprite) {
    var virtCanvas = document.createElement("canvas");
    virtCanvas.width = 500;
    virtCanvas.height = 500;
    var context = virtCanvas.getContext("2d");
    context.drawImage(sprite, 0, 0, 500, 500);

    var imgData = context.getImageData(0, 0, 500, 500);

    for (let i = 0; i < imgData.data.length; i += 4) {
        imgData.data[i] = imgData.data[i] * factor;
        imgData.data[i + 1] = imgData.data[i + 1] * factor;
        imgData.data[i + 2] = imgData.data[i + 2] * factor;
    }
    context.putImageData(imgData, 0, 0);

    var spriteOutput = new Image();
    spriteOutput.src = virtCanvas.toDataURL();
    virtCanvas.remove();
    return spriteOutput;
}

// Fonction de Victoire
function displayVictoryMess(moves) {
    // Bump la difficulté
    nombredelabfinit = nombredelabfinit + 1;
    let difficulty = 38;
    if(nombredelabfinit==1){
        difficulty = 15;
    }
    else if(nombredelabfinit==2){
        difficulty = 25;
    }
    else if(nombredelabfinit==3){
        difficulty = 38;
    }
    else if(nombredelabfinit==4){
        // Hack qui montre la fin au bout de 5s
        toggleVisibility("Message-Container");
        // Il vaut mieux quitter avant d'appeler `setTimeout`qui va déclencher la création d'un nouveau laby
    }
    // Affiche le message en attendant le prochain labyrinthe
    document.getElementById("moves").innerHTML = "Avec " + this.moves.length + " déplacements.";
    toggleVisibility("Message-Container");

    // Tente de valider le nouveau laby et annule
    fetch('validate', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            seed: this.maze.seed,
            difficulty: this.maze.height,
            moves: this.moves
        })
    })
    .then((res) => res.json())
    .then((data) => {
        if (data.ok) {
            setTimeout(function(){
                if (nombredelabfinit<4) {
                    makeMaze(window.maze.seed, difficulty);
                }
                toggleVisibility("Message-Container");
            }, 5000);
        } else if (!data.ok) {
            document.getElementById("end").innerHTML = `Le labyrinthe n'a pas pu être validé : ${data.reason}`;
            console.error(data);
        }
        // Affiche le flag si il est donné dans la réponse de validation
        if (data.ok && 'flag' in data) {
            document.getElementById("end").innerHTML = data.flag;
        }
    })
    .catch((err) => {
        document.getElementById("end").innerHTML = 'Erreur empêchant le labyrinthe d\'être validé';
        console.error(err);
    });
}

function toggleVisibility(id) {
    if (document.getElementById(id).style.visibility == "visible") {
        document.getElementById(id).style.visibility = "hidden";
    } else {
        document.getElementById(id).style.visibility = "visible";
    }
}

//Dessiner le labyrinthe
function DrawMaze(maze, ctx, cellSize, endSprite = null) {
    this.maze = maze
    this.map = maze.map();
    this.cellSize = cellSize; // FIXME: compter sur le fait que cellsize != cellSize... -> pourquoi redéfinir cellsize ?
    this.ctx = ctx;
    this.ctx.lineWidth = this.cellSize / 40; // Régler la taille des murs

    this.redrawMaze = function(size) {
        this.cellSize = size;
        this.ctx.lineWidth = this.cellSize / 50;
        this.drawMap();
        this.drawEnd();
    };

    this.drawCell = function(xCord, yCord, cell) {
        var x = xCord * this.cellSize;
        var y = yCord * this.cellSize;

        if (cell.n == false) {
            this.ctx.beginPath();
            this.ctx.moveTo(x, y);
            this.ctx.lineTo(x + this.cellSize, y);
            this.ctx.stroke();
        }
        if (cell.s === false) {
            this.ctx.beginPath();
            this.ctx.moveTo(x, y + this.cellSize);
            this.ctx.lineTo(x + this.cellSize, y + this.cellSize);
            this.ctx.stroke();
        }
        if (cell.e === false) {
            this.ctx.beginPath();
            this.ctx.moveTo(x + this.cellSize, y);
            this.ctx.lineTo(x + this.cellSize, y + this.cellSize);
            this.ctx.stroke();
        }
        if (cell.w === false) {
            this.ctx.beginPath();
            this.ctx.moveTo(x, y);
            this.ctx.lineTo(x, y + this.cellSize);
            this.ctx.stroke();
        }
    }

    this.drawMap = function() {
        for (x = 0; x < this.map.length; x++) {
            for (y = 0; y < this.map[x].length; y++) {
                this.drawCell(x, y, this.map[x][y]);
            }
        }
    }

    this.sprite = endSprite;
    this.drawEnd = function() {
        if (this.sprite === null)
        {
            var coord = this.maze.endCoord;
            var gridSize = 4;
            var fraction = this.cellSize / gridSize - 2;
            var colorSwap = true;
            for (let y = 0; y < gridSize; y++) {
                if (gridSize % 2 == 0) {
                    colorSwap = !colorSwap;
                }
                for (let x = 0; x < gridSize; x++) {
                    this.ctx.beginPath();
                    this.ctx.rect(
                    coord.x * this.cellSize + x * fraction + 4.5,
                    coord.y * this.cellSize + y * fraction + 4.5,
                    fraction,
                    fraction
                    );
                    if (colorSwap) {
                        this.ctx.fillStyle = "rgba(0, 0, 0, 0.8)";
                    } else {
                        this.ctx.fillStyle = "rgba(255, 255, 255, 0.8)";
                    }
                    this.ctx.fill();
                    colorSwap = !colorSwap;
                }
            }
        }
        else {
            var offsetLeft = this.cellSize / 50;
            var offsetRight = this.cellSize / 25;
            var coord = this.maze.endCoord;
            this.ctx.drawImage(
                this.sprite,
                2,
                2,
                this.sprite.width,
                this.sprite.height,
                coord.x * this.cellSize + offsetLeft,
                coord.y * this.cellSize + offsetLeft,
                this.cellSize - offsetRight,
                this.cellSize - offsetRight
            );
        }
    }

    this.clear = function() {
        var canvasSize = this.cellSize * this.map.length;
        this.ctx.clearRect(0, 0, canvasSize, canvasSize);
    }

    this.clear();
    this.drawMap();
    this.drawEnd();
}

function DrawPlayer(player, c, cellsize, sprite = null) {
    this.player = player;
    this.ctx = c.getContext("2d"); // créer le contexte de rendu 2D pour le canevas
    this.cellSize = cellsize;
    this.halfCellSize = this.cellSize / 2;

    this.redrawPlayer = function(cellsize) {
        this.cellSize = cellsize;
        this.drawSprite(this.player.cellCoords);
    };

    this.sprite = sprite;
    this.drawSprite = function(coord) {
        // drawSpriteCircle
        if (this.sprite === null) {
            this.ctx.beginPath(); //permet de commencer un nouveau chemin en vidant la liste des sous-chemins
            //ctx.fillStyle = "yellow";

            //https://developer.mozilla.org/fr/docs/Web/API/CanvasRenderingContext2D/arc
            this.ctx.arc( //
            (coord.x + 1) * this.cellSize - this.halfCellSize,
            (coord.y + 1) * this.cellSize - this.halfCellSize,
            this.halfCellSize - 2,
            0,
            2 * Math.PI
            );

        } else {
            //Intégration de l'image
            var offsetLeft = this.cellSize / 50;
            var offsetRight = this.cellSize / 25;
            //https://developer.mozilla.org/fr/docs/Web/API/CanvasRenderingContext2D/drawImage
            this.ctx.drawImage(
                this.sprite,
                0,
                0,
                this.sprite.width,
                this.sprite.height,
                coord.x * this.cellSize + offsetLeft,
                coord.y * this.cellSize + offsetLeft,
                this.cellSize - offsetRight,
                this.cellSize - offsetRight
            );
        }
    }

    //Supprimer le Sprite avant de le recréer après le changement de touche
    this.removeSprite = function(coord) {
        var offsetLeft = this.cellSize / 50;
        var offsetRight = this.cellSize / 25;
        this.ctx.clearRect(
            coord.x * this.cellSize + offsetLeft,
            coord.y * this.cellSize + offsetLeft,
            this.cellSize - offsetRight,
            this.cellSize - offsetRight
        );
    }

    this.redrawPlayer(this.cellSize);

    this.drawIfMoved = function(e) {
        const oldCoords = {...this.player.cellCoords};
        this.player.check(e);
        if (oldCoords != this.player.cellCoords)
        {
            this.removeSprite(oldCoords);
            this.drawSprite(this.player.cellCoords);
        }
        // Nécessité d'unbind si completed
        if (this.player.completed)
        {
            this.unbindKeyDown();
        }
    }

    this.bindKeyDown = function() {
        this._eventFunc = (e) => this.drawIfMoved(e);
        window.addEventListener("keydown", this._eventFunc, false);
        //Paramétrer l'utilisation sur smartphone ou ecran tactile grâce à : https://github.com/mattbryson/TouchSwipe-Jquery-Plugin
        $("#view").swipe({
            swipe: function(
                event,
                direction,
                distance,
                duration,
                fingerCount,
                fingerData
            ){
                console.log(direction);
                switch (direction) {
                    case "up":
                        check({
                        keyCode: 38
                        });
                        break;
                    case "down":
                        check({
                        keyCode: 40
                        });
                        break;
                    case "left":
                        check({
                        keyCode: 37
                        });
                        break;
                    case "right":
                        check({
                        keyCode: 39
                        });
                        break;
                }
            },
            threshold: 0
        });
    };

    // Vider le lab avant d'en recréer un
    this.unbindKeyDown = function() {
        window.removeEventListener("keydown", this._eventFunc, false);
        $("#view").swipe("destroy");
    };
    this.bindKeyDown();
}

// ####################-Start-#################### //

var mazeCanvas = document.getElementById("mazeCanvas");
var ctx = mazeCanvas.getContext("2d");
var finishSprite; // Ligne d'arrivee
var nombredelabfinit = 0;

// Adapter le labyrinthe à l'écran
window.onload = function() {
    let viewWidth = $("#view").width();
    let viewHeight = $("#view").height();
    if (viewHeight < viewWidth) {
        ctx.canvas.width = viewHeight - viewHeight / 100;
        ctx.canvas.height = viewHeight - viewHeight / 100;
    } else {
        ctx.canvas.width = viewWidth - viewWidth / 100;
        ctx.canvas.height = viewWidth - viewWidth / 100;
    }

    // Charger et edit les sprites

    // Sprite de début
    sprite = new Image();
    sprite.onerror = function(ev) {
        console.log('Error fetching', ev.target.src);
    }
    sprite.setAttribute("crossOrigin", " ");
    // Sprite de fin
    finishSprite = new Image();
    finishSprite.setAttribute("crossOrigin", " ");
    finishSprite.onerror = sprite.onerror;
    sprite.onload = function() {
        sprite = changeBrightness(1.2, sprite);
        finishSprite.src =
            "cci.png"; /*+
            "?" +
            new Date().getTime();*/
    };
    finishSprite.onload = function() {
        finishSprite = changeBrightness(1.1, finishSprite);
        console.log("Les Sprites sont bien chargés");
        fetch('get_seed', {method: 'POST'})
            .then((res) => res.json())
            .then((data) => {
                console.log("Seed bien récupérée");
                setTimeout(function(){
                    makeMaze(data.seed);
                }, 500);
            })
            .catch((err) => console.error(err))
    };
    sprite.src =
        "hacker.png"; /*+
        "?" +
        new Date().getTime();*/
};

// Rendre dynamique
window.onresize = function() {
    let viewWidth = $("#view").width();
    let viewHeight = $("#view").height();
    if (viewHeight < viewWidth) {
        ctx.canvas.width = viewHeight - viewHeight / 100;
        ctx.canvas.height = viewHeight - viewHeight / 100;
    } else {
        ctx.canvas.width = viewWidth - viewWidth / 100;
        ctx.canvas.height = viewWidth - viewWidth / 100;
    }
    cellSize = mazeCanvas.width / difficulty;
    if (window.player != null) {
        window.draw.redrawMaze(cellSize);
        window.draw_p.redrawPlayer(cellSize);
    }
};

// Bouton Start -> Fabriquer le labyrithe
function makeMaze(seed, difficulty = 10) {
    if (window.player != undefined) { //Si le joueur a déjà chargé un labyrinthe, vider l'actuel
        window.draw_p.unbindKeyDown();
        window.draw_p = null;
        window.player = null;
        window.draw = null;
        window.maze = null
    }
    cellSize = mazeCanvas.width / difficulty; //On crée le nombre de cellule en fonction de la difficulté
    window.maze = new Maze(difficulty, difficulty, seed); //Créer carré de la taille value dans l'html
    window.draw = new DrawMaze(window.maze, ctx, cellSize, finishSprite); //Dessiner le lab
    window.player = new Player(window.maze, displayVictoryMess);
    window.draw_p = new DrawPlayer(window.player, mazeCanvas, cellSize, sprite);
    if (document.getElementById("mazeContainer").style.opacity < "100") {
        document.getElementById("mazeContainer").style.opacity = "100";
    }
}
