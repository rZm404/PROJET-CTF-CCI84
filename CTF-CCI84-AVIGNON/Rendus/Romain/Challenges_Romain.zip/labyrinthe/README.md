# Challenge labyrinthe

Titre: Se perdre pour trouver l'introuvable
Niveau: débutant
Technologies/Techniques employées (mots cléfs): NodeJS
Mini Scénario: Il y a toujours une issue dans un Labyrinthe. Le temps parfois se fige et pourtant il ne suffit que d'une minute pour se perdre. 
Proposition Indice pour le scénario: Un labyrinthe n’est pas une impasse, un cul-de-sac, un piège. Mais un chemin qui ouvre sur d’autres chemins...
Flag: NHM2I{W3ll_D0nE_G0D_0F_L4Bys}

Résumé: Faire le labyrinthe, 4 niveaux puis le flag s'affiche. Dans la console, quand le labyrinthe commence->passer la variable nombredelabfinit à 3


# Installations des chall :

Le chall fonctionne avec un docker


## Construction du docker

Je suggère de tagguer l'image docker avec le numéro du commit sur lequel on est pour suivre les versions.
Sans modification par rapport au commit, le "-dirty" n'apparaîtra pas.

```
docker build -t chall_labyrinthe -t chall_labyrinthe:$(git log -1 --format='%h')$(git diff --quiet || echo '-dirty') .
```

Les images `chall_labyrinthe:latest` et `chall_labyrinthe:abcdef12` par exemple sont produites.


## Utilisation du docker

Le docker expose son port 8080 en http via NodeJS.
On peut remaper son port d'écoute avec la commande `docker run` :

```
docker run --rm -it -p 31337:1337/tcp chall_labyrinthe
```


# Test résolution

Charger la page, aller dans les dev tools (F12), charger un snippet (DevTools -> Sources -> partie gauche -> Snippets) : utiliser le `labyrinthe_solver_snippet.js` de ce dossier.
Clique droit dessus -> "Run", aller dans la console (en bas, sinon Echap si elle n'est pas là),
faire `solve()`, voir les messages s'afficher sur la page du labyrinthe,
attendre le nouveau labyrinthe avant de refaire solve,
4 fois de suite, boom flag.
