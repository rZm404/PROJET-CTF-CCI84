const express = require('express')
Math.seedrandom = require('seedrandom')
const { Maze, Player } = require('./res/labyrinthe.js')
const { subtle } = require('node:crypto').webcrypto

const FLAG = 'NHM2I{W3ll_D0nE_G0D_0F_L4Bys}';
const TIMEOUT = 60000;  // Il faut finir le labyrinthe en ce temps ou moins (en millisecondes)
const PORT = 8080


const app = express()
app.use(express.static('res'))

const iv = new Uint8Array([0x9d, 0x59, 0xe7, 0x9f, 0xe0, 0xd0, 0xfd, 0x0c, 0xab, 0xba, 0xa3, 0x11, 0x35, 0x17, 0x37, 0x37]);
const algo = {name: 'AES-CBC', iv};

function hexlify(a) {
    return [...new Uint8Array(a)].map((x) => x.toString(16).padStart(2, '0')).join('');
}

function unhexlify(s) {
    return Uint8Array.from(s.match(/.{2}/g).map((i) => parseInt(i, 16)));
}

app.post('/get_seed', (req, res) => {
    const ts = Date.now();
    const encoder = new TextEncoder();
    // The key does not protect strong secrets so it does not need to change
    // It only protects from people trying to obtain a future seed as the seed is encrypted into something seemingly random
    subtle.importKey('raw',
                     new Uint8Array([0x41, 0x9d, 0xa1, 0x25, 0xcd, 0xe3, 0xf0, 0xde, 0x1b, 0xa6, 0x36, 0xcf, 0x8f, 0xc9, 0x9b, 0x73]),
                     'AES-CBC', false, ['encrypt', 'decrypt'])
    .then((key) => {
        return subtle.encrypt(algo, key, encoder.encode(JSON.stringify({
            ts
        })));
    }).then((payload) => {
        res.json({seed: hexlify(payload)});
    }).catch((error) => {
        console.error(error);
        res.json({error: error.toString()});
    });
})

app.use('/validate', express.json())
app.post('/validate', (req, res) => {
    // Validate seed
    const payload = unhexlify(req.body.seed);
    subtle.importKey('raw',
                     new Uint8Array([0x41, 0x9d, 0xa1, 0x25, 0xcd, 0xe3, 0xf0, 0xde, 0x1b, 0xa6, 0x36, 0xcf, 0x8f, 0xc9, 0x9b, 0x73]),
                     'AES-CBC', false, ['encrypt', 'decrypt'])
    .then((key) => {
        return subtle.decrypt(algo, key, payload)
    }).then((buf) => {
        const decoder = new TextDecoder();
        const d = JSON.parse(decoder.decode(buf));
        console.log(d);
        const ts = d.ts;
        if (Date.now()-ts >= TIMEOUT) {
            console.error(`Too slow ${Date.now()-ts}ms`);
            res.json({ok: false, reason: 'timeout'});
        }
        else {
            // Validate moves
            console.log(req.body);
            if (!('moves' in req.body) || !('difficulty' in req.body)) {
                res.json({ok: false, reason: 'missing difficulty or moves'});
            } else {
                const moves = req.body.moves;
                const difficulty = req.body.difficulty;
                let maze = new Maze(difficulty, difficulty, req.body.seed);
                let player = new Player(maze, () => {
                    if(difficulty >= 38) {
                        res.json({ok: true, flag: FLAG});
                    } else {
                        res.json({ok: true, tip: 'Play in higher difficulty for the flag'});
                    }
                });
                for (const e of moves) {
                    player.check(e)
                }
                if (! player.completed) {
                    res.json({ok: false, reason: 'invalid moves'});
                }
            }
        }
    }).catch((e) => {
        console.error(e);
        if (! res.headersSent) {
            res.json({ok: false});
        }
    });
    //res.json({ok: true});
})

// The `res.redirect()` function sends back an HTTP 302 by default.
// When an HTTP client receives a response with status 302, it will send
// an HTTP request to the URL in the response, in this case `/to`
// Redirects home page to chall page
app.get('/', (req, res) => {
    res.redirect('/play_labyrinthev1.html');
});

app.listen(PORT, () => {
    console.log(`Example app listening on port ${PORT}`)
})
