compteur et labyrinthe :
Les heberger sur un serveur web (apache par exemple) et aller à l'url associée
ou installer l'extension live server sur VSCode
input_print :
run.py permet de jouer le challenge
solve.py contient le dictionnaire pour traduire, et les explications
Pour l'instant il n'y a pas de limite de temps

