  $(document).ready(function() {
    // DataTable initialisation
    $('#example').DataTable(
        {
            "paging": false,
            "autoWidth": true,
            "footerCallback": function ( row, data, start, end, display ) {
                var api = this.api();
                nb_cols = api.columns().nodes().length;
                var j = 1;
                while(j < nb_cols){
                    var pageTotal = api
                        .column(j)
                        .data()
                        .reduce( function (a, b) {
                            return (Number(a) + Number(b));
                        }, 0 );
            // Update footer
            $( api.column( j ).footer() ).html(pageTotal/9);    
                    j++;
                } 
            }
        }
    );
    });
    setInterval(function() {
        moyenne = parseFloat(document.getElementById("1").innerHTML)+parseFloat(document.getElementById("2").innerHTML)+parseFloat(document.getElementById("3").innerHTML)+parseFloat(document.getElementById("4").innerHTML)+parseFloat(document.getElementById("5").innerHTML)+parseFloat(document.getElementById("6").innerHTML)+parseFloat(document.getElementById("7").innerHTML)+parseFloat(document.getElementById("8").innerHTML)+parseFloat(document.getElementById("9").innerHTML);
        console.log(moyenne);
        int = parseFloat(moyenne/9);
        document.getElementById("moyenne").innerHTML = int;
		if(int>16){
			alert("NHM2I{FMHF1DS2G9GH4D26DCA4S}");
		}
        console.log("coucou");
    }, 1000);