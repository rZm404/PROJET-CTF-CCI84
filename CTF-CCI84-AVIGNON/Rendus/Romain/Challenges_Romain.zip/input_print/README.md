# Challenge Decode et try hard

Titre: Decode et try hard
Niveau: Facile
Technologies/Techniques employées (mots cléfs): Python/Logique
Mini Scénario: Un texte chiffré nous a été envoyé, trouvez le moyen de comprendre ce qu'ils racontent
Proposition Indice pour le scénario: X
Flag: NHM2I{mon_41ph4b3t_vous_c0nn41ss3z}

Résumé: Un texte chiffré de manière inhabituelle

## Construction du docker
```
docker build --pull --rm -f "dockerfile" -t decode_message_and_send "." 
```

L'image `decode_message_and_send` est produite.


## Utilisation du docker

```
docker run -it decode_message_and_send
```
# Test résolution
Ecrire l'alphabet en commentaire et enlever les lettres trouvées au fur et à mesure
Dans le texte chiffré, on reconnait le format d'une url, on peut donc déjà remplacer
HTTPS://WWW
Puis on essai de deviner lettre par lettre ce qu'il manque et on obtient le dictionnaire corrigé
Une fois que le dictionnaire est rempli, on peut traduire mot par mot et obtenir le flag
