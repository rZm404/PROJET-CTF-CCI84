cipher_text = "QCISW SWBR SVGVJ EV DIRRVC UI DCVZFVCV VYIDV EV OV OLIUUVGPV, YWBYVR GWR TVUFOFYIYFWGR IB GWZ EV LYYDR://NNN.UFGXVEFG.OWZ/OWZDIGH/LIOXFGDCWSVGOV/"
plain_text = ""
"""
Ecrire l'alphabet en commentaire et enlever les lettres trouvées au fur et à mesure
Dans le texte chiffré, on reconnait le format d'une url, on peut donc déjà remplacer
HTTPS://WWW
Puis on essai de deviner lettre par lettre ce qu'il manque et on obtient ce dictionnaire :
JQX
Une fois que le dictionnaire est rempli, on peut traduire mot par mot et obtenir le flag
"""
changement_alphabet = {   
    "A" : "A",
    "B" : "U",
    "C" : "R",
    "D" : "P",
    "E" : "D",
    "F" : "I",
    "G" : "N",
    "H" : "Y",
    "I" : "A",
    "J" : "Z",
    "K" : "K",
    "L" : "H",
    "M" : "M",
    "N" : "W",
    "O" : "C",
    "P" : "G",
    "Q" : "B",
    "R" : "S",
    "S" : "V",
    "T" : "F",
    "U" : "L",
    "V" : "E",
    "W" : "O",
    "X" : "K",
    "Y" : "T",
    "Z" : "M",
    ":" : ":",
    "." : ".",
    "/" : "/",
    "-" : "-",
    " " : " ",
    "," : ","
}
print(cipher_text)
print("---")
for i in cipher_text:
    plain_text+=changement_alphabet[i]
print(plain_text)
print("---")
print(plain_text.lower())