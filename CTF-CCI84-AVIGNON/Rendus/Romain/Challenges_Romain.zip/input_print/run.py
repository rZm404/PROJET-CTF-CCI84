plain_text="BRAVO VOUS VENEZ DE PASSER LA PREMIERE ETAPE DE CE CHALLENGE, TOUTES NOS FELICITATIONS AU NOM DE HTTPS://WWW.VAUCLUSE.CCI.FR/"
cipher_text = ""
mot1 = "J'ESPERE"
mot2 = "QUE"
mot3 = "VOUS"
mot4 = "AVEZ"
mot5 = "AIME"
mot6 = "CE"
mot7 = "CHALLENGE"
mot8 = "VOICI"
mot9 = "LE"
mot10 = "FLAG"
motFinal= "NHM2I{mon_41ph4b3t_est_l3_t13n}"
def cipher(plaintext):
    cipher_text = ""
    changement_alphabet = {   
        "A" : "I",
        "B" : "Q",
        "C" : "O",
        "D" : "E",
        "E" : "V",
        "F" : "T",
        "G" : "P",
        "H" : "L",
        "I" : "F",
        "J" : "M",
        "K" : "X",
        "L" : "U",
        "M" : "Z",
        "N" : "G",
        "O" : "W",
        "P" : "D",
        "Q" : "A",
        "R" : "C",
        "S" : "R",
        "T" : "Y",
        "U" : "B",
        "V" : "S",
        "W" : "N",
        "X" : "K",
        "Y" : "H",
        "Z" : "J",
        ":" : ":",
        "." : ".",
        "/" : "/",
        "-" : "-",
        " " : " ",
        "," : ",",
        "'" : "'",
    }
    for i in plaintext:
        cipher_text+=changement_alphabet[i]
    return cipher_text
print("Aidez nous à comprendre ce texte...")
print(cipher(plain_text), "\n")
print("Quand c'est fait, aidez nous à comprendre le reste :")
print(cipher(mot1))
answer1 = input(">")
try:
    if answer1==mot1:
        print(cipher(mot2))
        answer2 = input(">")
        if answer2==mot2:
            print(cipher(mot3))
            answer3 = input(">")
            if answer3==mot3:
                print(cipher(mot4))
                answer4 = input(">")
                if answer4==mot4:
                    print(cipher(mot5))
                    answer5 = input(">")
                    if answer5==mot5:
                        print(cipher(mot6))
                        answer6 = input(">")
                        if answer6==mot6:
                            print(cipher(mot7))
                            answer7 = input(">")
                            if answer7==mot7:
                                print(cipher(mot8))
                                answer8 = input(">")
                                if answer8==mot8:
                                    print(cipher(mot9))
                                    answer9 = input(">")
                                    if answer9==mot9:
                                        print(cipher(mot10))
                                        answer10 = input(">")
                                        if answer10==mot10:
                                            print(motFinal)
                                    else:
                                        print("Nop..")
                                else:
                                    print("Nop..")
                            else:
                                print("Nop..")
                        else:
                            print("Nop..")
                    else:
                        print("Nop..")
                else:
                    print("Nop..")                    
            else:
                print("Nop..")
        else:
            print("Nop..")
    else:
        print("Nop..")
except KeyboardInterrupt:
    exit()
