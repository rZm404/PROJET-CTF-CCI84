#!/usr/bin/env python3

import sys

# TODO: il manque le M->J dans la phrase de première étape
TRAD = {k:v for k,v in zip('NLYDRVOWZBIGEUPCFTXSJQMA',
                           'whtpsecomuandlgrifkvzbjq')}

if __name__ == '__main__':
    for i, line in enumerate(sys.stdin):
        trad = ''.join(TRAD.get(c,c) for c in line)
        print(trad, end='', file=sys.stderr)
        if i > 3:
            print(trad.replace('>','').upper(), end='', flush=True)
